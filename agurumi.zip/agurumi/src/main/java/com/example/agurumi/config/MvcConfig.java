package com.example.agurumi.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;

public class MvcConfig {
    @Value("${upload.path}")
    private String uploadPath;
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/img/**").addResourceLocations("file://" + uploadPath + "/");
    }

}
