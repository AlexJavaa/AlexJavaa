package com.example.agurumi.repository;

import com.example.agurumi.models.Post;
import org.springframework.data.repository.CrudRepository;

public interface PostRepository extends CrudRepository<Post, Long> {

}
