package com.example.agurumi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgurumiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgurumiApplication.class, args);
	}

}
