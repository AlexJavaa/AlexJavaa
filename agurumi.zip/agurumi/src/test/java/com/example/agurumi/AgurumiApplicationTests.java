package com.example.agurumi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgurumiApplicationTests {

	@Test
	void contextLoads() {
	}

}
